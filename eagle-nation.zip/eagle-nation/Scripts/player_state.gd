##Base class for [PlayerState].[br]
##Requires a reference [member player] and [member player_state_machine]
class_name PlayerState
extends Node

##Name of the state instance. Used to identify the state by the [PlayerStateMachine].[br]
##Hard defined property for every class deriving from the base state. Should never change at runtime.
@export var state_name: String
##Reference to the [PlayerStateMachine]. Required to call the transition to new state from[br]
##within each [PlayerState]
var player_state_machine: PlayerStateMachine
##Reference to the [Player] as it need to pull data and reference from it.
var player: Player = null


##Initializes the state by setting the references [member player_state_machine] to [PlayerStateMachine][br]
##and [member player] to the [Player].
func init_state(new_state_machine: PlayerStateMachine, new_player: Player) -> void:
	player_state_machine = new_state_machine
	player = new_player


##Base functionality called when entering the state. Start the animation based on [member state_name][br]
##and sets the speed scale to 1.0 (default). Calls the private method [method on_enter] which is ment[br]
##to be customized for each state (if necessary) by the states needs. I.e. a evade state can disable[br]
##the collision for a duration initially.
func enter_state() -> void:
	player.animation_player.speed_scale = 1.0
	player.animation_player.start_animation(state_name)
	on_enter() 


##Virtual function that provides the option to execute code once the base functionality of the[br]
##state transition has finished.
func on_enter() -> void:
	pass


##Interface for the [PlayerStateMachine] to pass the delta to as nodes to not act on their own[br]
##but only when they are currently the active state.
func physics_process(_delta: float) -> void:
	pass


##Interface for the [PlayerStateMachine] to pass the delta to as nodes to not act on their own[br]
##but only when they are currently the active state.
func process(_delta: float) -> void:
	pass

##Virtual function that provides the option to execute code at leaving the state Use to clean up[br]
##lose ends so they dont carry over.
func exit_state() -> void:
	pass


##Getter for the state name.
func get_state_name() -> String:
	return state_name
