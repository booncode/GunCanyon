##[InputSet] stores all [Input] by the player for use within [PlayerState] to have persistent inputs[br]
##and do not loss anything between transitions. Strict data-container. Data is directly accessed[br]
##without setter / getter functions except for [method clear] which clears the [Input].
class_name InputSet
extends RefCounted

##Keyboardstroke [member move_left]
var move_left: bool = false
##GamePad left stick x-axis input
var stick_left_x: float = 0.0
##Keyboardstroke [member move_right]
var move_right: bool = false
##GamePad left stick y-axis input
var stick_left_y: float = 0.0
##Jump key/button pressed
var jump: bool = false
##Sprint key/button pressed
var sprint: bool = false
##Attack key/button pressed
var attack: bool = false


##Resets all inputs to default, effectively clearing them.
func clear() -> void:
	move_left = false
	stick_left_x = 0.0
	move_right = false
	stick_left_y = 0.0
	jump = false
	sprint = false
	attack = false
