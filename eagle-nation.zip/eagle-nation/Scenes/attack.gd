##The Attack [PlayerState] calculates attack time, oversights the current attack frame[br]
##and applies damage after checking collisions.
class_name AttackState
extends PlayerState

##The currently left stagger duration
var attack_windup: float = 0.0

##The [AttackState] [method physics_process] checks the windup time and applies damage base on collision.
func physics_process(_delta: float) -> void:
	
	attack_windup -= _delta
	if attack_windup <= 0.0:
		print("would check for collision and apply damage")
		player_state_machine.transition_state("idle")
		return


##We need to overwrite the regular function for [AttackState] as it uses different animations with[br]
##non of them matching the states name directly
#func enter_state() -> void:
	#on_enter()


##When entering [LandState] we check for the exit velocity from [JumpState]. If it breaks the threshold[br]
##we apply a stagger timer.
func on_enter() -> void:
	player.velocity = Vector2.ZERO
	attack_windup = player.attack_timer
	#var attack_animation: int = randi_range(1,2)
	#print("%s_%d" % [state_name, attack_animation])
	#player.animation_player.start_animation("%s_%d" % [state_name, attack_animation])
	player.animation_player.start_animation(state_name)
	#player.animation_player.adjust_animation_time(attack_windup, "%s_%d" % [state_name, attack_animation])
	player.animation_player.adjust_animation_time(attack_windup, state_name)
