##The Walk [PlayerState] checks for inputs and adds velocity. When reaching run velocity switches to run [PlayerState].
class_name WalkState
extends PlayerState


##The [WalkState] [method physics_process] checks for transitions and moves the player while on ground.
func physics_process(_delta: float) -> void:
	#We get the direction value based on the inputs
	var direction: float = float(player.input_set.move_right) - float(player.input_set.move_left)
	
	#In case we are not on the floor change to the jump state as it has priority over walk as it also
	#represents "falling"
	if not player.is_on_floor():
		player_state_machine.transition_state("jump")
		return
	
	#We check if jump has been pressed while walking as it does have, again, priority over walking
	if Input.is_action_just_pressed("JUMP"):
		player_state_machine.transition_state("jump")
		return
	
	#Check if we want to attack
	if player.input_set.attack:
		player_state_machine.transition_state("attack")
		return
	
	#We check if there is a direction and if so we move otherwise we deccelerate
	if direction:
		if player.input_set.sprint:
			player_state_machine.transition_state("sprint")
			return
		else:
			player.velocity.x = direction * player.movement_speed
			player.sprite_flip_h = player.velocity.x < 0
	else:
		player.velocity.x = move_toward(player.velocity.x, 0, player.movement_speed)
	
	#If we do not have any direction or momentum left we go back to idle
	if player.velocity == Vector2.ZERO:
		player_state_machine.transition_state("idle")
		return
