##[PlayerAnimation] provides methods to manipulate the [Player] [AnimationPlayer] based on both
##[PlayerState] and [GameState]. Every [PlayerState] calls this on enter to change the [Animation]
class_name PlayerAnimation
extends AnimationPlayer


##Chagnes the the [Animation] for the [Player] based on the entered [PlayerState] name.
func start_animation(new_state_name: String) -> void:
	if not has_animation(new_state_name):
		push_error("[%s] Animation %s is missing" % ["Player", new_state_name])
	else:
		play(new_state_name)


##Adjusts the current [Animation] runtime by a provided factor. Used for variable [Animation][br]
##times like when entering [LandState] as the stagger varies based on previous speed.
func adjust_animation_time(target_time: float, animation_name: String) -> void:
	var _current_animation: Animation = get_animation(animation_name)
	var animation_length: float = _current_animation.length
	if target_time > 0.0:
		speed_scale = animation_length / target_time
	else:
		push_error("[%s]Error when recalculating the aniamtion time, dividing by 0" % [self])
