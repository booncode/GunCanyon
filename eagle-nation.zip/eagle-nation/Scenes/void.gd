##The void [PlayerState] kills the player when the velocy y reaches a terminal point.
class_name VoidState
extends PlayerState


##The [VoidState] cleans up and sets the [GameState] to [GameOver]
func physics_process(_delta: float) -> void:
	print("Game Over")
