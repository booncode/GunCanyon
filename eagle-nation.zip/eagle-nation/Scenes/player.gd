##This is the player scene. Controlled by the player. Grabs and holds all the [Input] so they can[br]
##be used by each [PlayerState] logic.
class_name Player
extends CharacterBody2D

##Reference to the [Sprite2D] attached to the [Player] to be used by [PlayerState] and the [AnimationPlayer].
@onready var sprite: Sprite2D = $Sprite2D
##Reference to the [CollisionShape2D] the player uses for both collision and as hurtbox.
@onready var collision: CollisionShape2D = $Collision
##Reference to the [AnimationPlayer] used to animate the [Player] based on the current [PlayerState]
@onready var animation_player: PlayerAnimation = $AnimationPlayer
##Reference to the [PlayerStateMachine] which decides the transition of [PlayerState].
@onready var player_state_machine: PlayerStateMachine = $PlayerStateMachine

@export_group("Player Stats")
##The [member movement_speed] for the [Player].
@export var movement_speed: float = 150.0
##The [member jump_velocity] used to initially push the [Player] off the ground.
@export var jump_velocity = -250.0
##The [member attack_time] determines how long an attack takes, has direct influence on animation and control.
@export var attack_timer: float = 0.2
##Whenever the [member velocity] is negative fot the x value we change this variable create persistence.
var sprite_flip_h: bool = false
##An instance of [InputSet] hold by the [Player] to store [Input] within the frame.
var input_set: InputSet = InputSet.new()
##Stores the final y-velocity the [Player] had before touching ground.
var final_speed: float = 0.0


##Callback [method _ready] is used set up all references for the [Player] children [Node][br]
##like [member sprite], [member collision], [member animation_player] and others. Sets up[br]
##the [PlayerStateMachine] so [Player] can get into a valid [PlayerState]
func _ready() -> void:
	player_state_machine.init_state_machine(self)


##Callback [method _physics_process] is used to pass the delta to the [PlayerStateMachine].
func _physics_process(delta: float) -> void:
	input_set = get_inputs()
	player_state_machine.physics_process(delta)
	move_and_slide()


##Callback [method _process] is used to manipulate the [member sprite] and everthiny rendering[br]
##that isnt already done in the states.
func _process(_delta: float) -> void:
	sprite.flip_h = sprite_flip_h


##Creates a new instance of [InputSet], grabs all current [Input], updates [InputSet] based on them[br]
##returning the new set for use within the physics frame.
func get_inputs() -> InputSet:
	var new_input_set: InputSet = InputSet.new()
	new_input_set.move_left = Input.is_action_just_pressed("MOVE_LEFT") or Input.is_action_pressed("MOVE_LEFT")
	new_input_set.move_right = Input.is_action_just_pressed("MOVE_RIGHT") or Input.is_action_pressed("MOVE_RIGHT")
	new_input_set.jump = Input.is_action_just_pressed("JUMP") or Input.is_action_pressed("JUMP")
	new_input_set.sprint = Input.is_action_just_pressed("SPRINT") or Input.is_action_pressed("SPRINT")
	new_input_set.attack = Input.is_action_just_pressed("ATTACK") or Input.is_action_pressed("ATTACK")
	return new_input_set
