##The land [PlayerState] is transitioned to when [Player] lands. Checks for height as we apply[br]
##a "staggering" depending on the height if a certain threshold is met.
class_name LandState
extends PlayerState

##The currently left stagger duration
var stagger_timer: float = 0.0

##The [LandState] [method physics_process] checks for the previous velocity and appies staggering[br]
##if a the threshold is met. Staggering grows within limits.
func physics_process(_delta: float) -> void:
	#We need to take a snapshot of inputs here and create an input list
	#to act on for the current frame to not lose inputs due to changes in states
	if not player.is_on_floor():
		player_state_machine.transition_state("jump")
		return
	
	stagger_timer -= _delta
	if stagger_timer <= 0.0:
		player_state_machine.transition_state("idle")
		return


##When entering [LandState] we check for the exit velocity from [JumpState]. If it breaks the threshold[br]
##we apply a stagger timer.
func on_enter() -> void:
	stagger_timer = 0.0
	if player.final_speed >= GameConsts.FALLING_SPEED_STAGGER_THRESSHOLD:
		player.velocity = Vector2.ZERO
		stagger_timer = GameConsts.BASE_STAGGERING_TIME
		player.animation_player.adjust_animation_time(stagger_timer, state_name)
