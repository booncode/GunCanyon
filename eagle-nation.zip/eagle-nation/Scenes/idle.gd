##The idle [PlayerState] serves as the default state. This state is entered when no inputs[br]
##or external forces / signals are applied to [Player]
class_name IdleState
extends PlayerState


##The [IdleState] [method physics_process] grabs all inputs and external forces to check[br]
##if a transition of [PlayerState] is required to be requested with the [PlayerStateMachine]
func physics_process(_delta: float) -> void:
	#We need to take a snapshot of inputs here and create an input list
	#to act on for the current frame to not lose inputs due to changes in states
	if not player.is_on_floor():
		player_state_machine.transition_state("jump")
		return
	
	#Check for jump
	if player.input_set.jump:
		player_state_machine.transition_state("jump")
		return
	
	#Check if we want to attack
	if player.input_set.attack:
		player_state_machine.transition_state("attack")
		return
	
	#Check if we moved
	if player.input_set.move_left or player.input_set.move_right:
		if player.input_set.sprint:
			player_state_machine.transition_state("sprint")
			return
		else:
			player_state_machine.transition_state("walk")
			return
	#If nothing happens we set the velocity to zero in case there is some left over
	player.velocity = Vector2.ZERO
