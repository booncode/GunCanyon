##The Jump [PlayerState] sets the animation and applies force until the player either lands, gets hit[br]
##or reaches a terminal velocity from either extreme height or falling into a void.
class_name JumpState
extends PlayerState


##The [JumpState] [method physics_process] checks for velocity to see if a terminal one is reached[br]
func physics_process(delta: float) -> void:
	#We get the direction value based on the inputs
	var direction: float = float(player.input_set.move_right) - float(player.input_set.move_left)
	
	#Lets check if the playeyr is in air so we can apply gravity and also direction otherwise we are idle
	if not player.is_on_floor():
		player.velocity += player.get_gravity() * delta
		#We check for the terminal velocity
		if player.velocity.y >= GameConsts.TERMINAL_Y_VELOCITY:
			player_state_machine.transition_state("void")
		#If there is an input we move accordingly, if not we just "slow down"
		if direction:
			if player.input_set.sprint:
				player.velocity.x = direction * player.movement_speed * 1.5
				player.sprite_flip_h = player.velocity.x < 0
			else:
				player.velocity.x = direction * player.movement_speed
				player.sprite_flip_h = player.velocity.x < 0
		else:
			player.velocity.x = move_toward(player.velocity.x, 0, player.movement_speed)
		#We store the current y-velocity
		player.final_speed = player.velocity.y
	else:
		#If we hit ground we transition to land
		player_state_machine.transition_state("land")


##Adds the [Player] jump velocity when conditions are met. Right now this is the case if we enter[br]
##[JumpState] while still beeing on the ground.
func on_enter() -> void:
	var jump_multiplicator: float = 0.0
	if player.player_state_machine.previous_state.get_state_name() == "sprint":
		jump_multiplicator = 0.3
	
	if player.is_on_floor():
		player.velocity.y = player.jump_velocity * ( 1.0 + jump_multiplicator)
