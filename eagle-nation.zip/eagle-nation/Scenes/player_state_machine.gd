##Regulates and performs transition between states for the player with [method transition_state] taking the required[br]
##[member state_name] as parameter
class_name PlayerStateMachine
extends Node

##Reference to [Player] to pull data from.
var player: Player = null
##Holds all [PlayerState] known to the [Player] so we can pull from it.
var player_state_list: Dictionary[String,PlayerState] = {}
##The current [PlayerState] the [Player] is in right now. The delta is always passed to this state.
var current_state: PlayerState = null
##Holds a reference to the previous [PlayerState] for more complex decisions.
var previous_state: PlayerState = null

##This is the default [PlayerState] the [PlayerStateMachine] will try to begin with when[br]
##it is first initialized with [method init_state_machine]
@export var init_state: String = "idle"


##Interface to pass the delta received by the [Player] to the currently active state. With this[br]
##the system can ensure no other state is processes ad any time.
func physics_process(_delta: float) -> void:
	current_state.physics_process(_delta)


##Initializes the [PlayerStateMachine] by iterating through of its children and adding every[br]
##child that is of [PlayerState] to the [member player_state_list] and starts kicking off[br]
##by setting the current_state to [member init_state].
func init_state_machine(new_player: Player) -> void:
	player = new_player
	# Collect the children, check if its actually state and not some other nonsense
	for child in get_children():
		if child is PlayerState:
			# We create the references necessary and add it to the list
			child.init_state(self, new_player)
			player_state_list[child.get_state_name().to_lower()] = child
	if player_state_list.has(init_state):
		current_state = player_state_list[init_state]
		enter_state(current_state)
	else:
		push_error("[%s].[%s] Can't find default state %s" % [player.name, name,init_state])


##Transition the [member current_state] to the requested [PlayerState] based on the [PlayerState] name.[br]
##Checks if the state exists and if so exits the [member current_state] assigns it to [member previous_state][br]
##and assigns the requested [PlayerState] to [member current_state]
func transition_state(new_state_name: String) -> void:
	if new_state_name == current_state.get_state_name():
		push_error("[%s] State is already %s" % [self.name ,new_state_name])
		return
	if player_state_list.has(new_state_name):
		previous_state = current_state
		current_state = player_state_list[new_state_name]
		exit_state(previous_state)
		enter_state(current_state)
	else:
		push_error("[%s] State %s does not exist" % [self.name ,new_state_name])


##Enters a [PlayerState] by calling its enter method. This function is used for logging in debug sessions.
func enter_state(new_state: PlayerState) -> void:
	print("[%s].[%s] Entering the state %s" % ["Player", name, new_state.get_state_name()])
	new_state.enter_state()


##Exits a [PlayerState] by calling its exit method. This function is used for logging in debug sessions.
func exit_state(old_state: PlayerState) -> void:
	print("[%s].[%s] Exiting the state %s" % ["Player", name, old_state.get_state_name()])
	old_state.exit_state()


##Getter function to get the name of the currently active [PlayerState]
func get_current_state() -> String:
	return current_state.get_state_name()


##Checks the [member current_state] against the provided String.
func check_if_state_is(state_name: String) -> bool:
	return current_state.get_state_name() == state_name
