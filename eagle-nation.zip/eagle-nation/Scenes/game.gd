##The main class [Game] acts on [GameState]
class_name Game
extends Node2D


##Called once all nodes in the tree are ready. [Game] sets the initial [GameState] to [InitGameState][brb]
##and initialzes all data and shaders.
func _ready() -> void:
	pass
