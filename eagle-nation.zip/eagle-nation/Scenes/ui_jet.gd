extends Sprite2D


var speed: float = 900.0
var spawn_position: Vector2
var pause_timer: float = 0.0

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	spawn_position = position


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _physics_process(delta: float) -> void:
	if pause_timer <= 0.0:
		var velocity: Vector2 = Vector2(-1.0, 0.0) * speed
		position += velocity * delta
	pause_timer -= delta
	if position.x <= 0.0:
		position = spawn_position
		pause_timer = 10.00
