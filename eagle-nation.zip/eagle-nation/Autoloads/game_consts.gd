extends Node

##The y-velocity threshold for [Player] to reach in order to die from falling.
const TERMINAL_Y_VELOCITY: float = 1500.00
##The y-velocity threshold to add staggering on landing.
const FALLING_SPEED_STAGGER_THRESSHOLD: float = 400.0
##The base staggering time when triggered
const BASE_STAGGERING_TIME: float = 0.25
